import{c as t,j as e,m as a}from"./index-DJepuYhB.js";import{U as x}from"./users-DUvZKpdI.js";import{H as y}from"./home-DIRrLKtf.js";/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=t("Baby",[["path",{d:"M9 12h.01",key:"157uk2"}],["path",{d:"M15 12h.01",key:"1k8ypt"}],["path",{d:"M10 16c.5.3 1.2.5 2 .5s1.5-.2 2-.5",key:"1u7htd"}],["path",{d:"M19 6.3a9 9 0 0 1 1.8 3.9 2 2 0 0 1 0 3.6 9 9 0 0 1-17.6 0 2 2 0 0 1 0-3.6A9 9 0 0 1 12 3c2 0 3.5 1.1 3.5 2.5s-.9 2.5-2 2.5c-.8 0-1.5-.4-1.5-1",key:"5yv0yz"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=t("Car",[["path",{d:"M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2",key:"5owen"}],["circle",{cx:"7",cy:"17",r:"2",key:"u2ysq9"}],["path",{d:"M9 17h6",key:"r8uit2"}],["circle",{cx:"17",cy:"17",r:"2",key:"axvx0g"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const k=t("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=t("Dumbbell",[["path",{d:"m6.5 6.5 11 11",key:"f7oqzb"}],["path",{d:"m21 21-1-1",key:"cpc6if"}],["path",{d:"m3 3 1 1",key:"d3rpuf"}],["path",{d:"m18 22 4-4",key:"1e32o6"}],["path",{d:"m2 6 4-4",key:"189tqz"}],["path",{d:"m3 10 7-7",key:"1bxui2"}],["path",{d:"m14 21 7-7",key:"16x78n"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=t("ShieldCheck",[["path",{d:"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10",key:"1irkt0"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=t("Sparkles",[["path",{d:"m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z",key:"17u4zn"}],["path",{d:"M5 3v4",key:"bklmnn"}],["path",{d:"M19 17v4",key:"iiml17"}],["path",{d:"M3 5h4",key:"nem4j1"}],["path",{d:"M17 19h4",key:"lbex7p"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=t("Sun",[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=t("Trees",[["path",{d:"M10 10v.2A3 3 0 0 1 8.9 16v0H5v0h0a3 3 0 0 1-1-5.8V10a3 3 0 0 1 6 0Z",key:"yh07w9"}],["path",{d:"M7 16v6",key:"1a82de"}],["path",{d:"M13 19v3",key:"13sx9i"}],["path",{d:"M12 19h8.3a1 1 0 0 0 .7-1.7L18 14h.3a1 1 0 0 0 .7-1.7L16 9h.2a1 1 0 0 0 .8-1.7L13 3l-1.4 1.5",key:"1sj9kv"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=t("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=t("Tv",[["rect",{width:"20",height:"15",x:"2",y:"7",rx:"2",ry:"2",key:"10ag99"}],["polyline",{points:"17 2 12 7 7 2",key:"11pgbg"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=t("Waves",[["path",{d:"M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"knzxuh"}],["path",{d:"M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"2jd2cc"}],["path",{d:"M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",key:"rd2r6e"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=t("Wifi",[["path",{d:"M5 13a10 10 0 0 1 14 0",key:"6v8j51"}],["path",{d:"M8.5 16.5a5 5 0 0 1 7 0",key:"sej527"}],["path",{d:"M2 8.82a15 15 0 0 1 20 0",key:"dnpr2z"}],["line",{x1:"12",x2:"12.01",y1:"20",y2:"20",key:"of4bc4"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=t("Wind",[["path",{d:"M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2",key:"1k4u03"}],["path",{d:"M9.6 4.6A2 2 0 1 1 11 8H2",key:"b7d0fd"}],["path",{d:"M12.6 19.4A2 2 0 1 0 14 16H2",key:"1p5cb3"}]]);/**
 * @license lucide-react v0.309.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=t("Zap",[["polygon",{points:"13 2 3 14 12 14 11 22 21 10 12 10 13 2",key:"45s27k"}]]);function D(){const d=[{title:"Recreation & Wellness",icon:l,amenities:[{icon:N,name:"Swimming Pool",description:"Olympic-sized swimming pool with dedicated lanes"},{icon:l,name:"Fitness Center",description:"State-of-the-art gym with modern equipment"},{icon:f,name:"Sports Facilities",description:"Tennis courts, basketball court, and recreational areas"},{icon:j,name:"Landscaped Gardens",description:"Beautifully maintained green spaces and gardens"}]},{title:"Security & Safety",icon:c,amenities:[{icon:c,name:"24/7 Security",description:"Round-the-clock security personnel and monitoring"},{icon:w,name:"CCTV Surveillance",description:"Comprehensive camera coverage throughout the estate"},{icon:c,name:"Gated Community",description:"Controlled access with advanced security systems"},{icon:k,name:"Emergency Response",description:"Rapid response team for all emergencies"}]},{title:"Infrastructure & Utilities",icon:o,amenities:[{icon:o,name:"24-Hour Power Supply",description:"Uninterrupted power with backup generators"},{icon:C,name:"High-Speed Internet",description:"Fiber-optic internet connectivity"},{icon:M,name:"Central Air Conditioning",description:"Climate control in all units"},{icon:b,name:"Solar Power Integration",description:"Eco-friendly solar energy systems"}]},{title:"Convenience & Lifestyle",icon:y,amenities:[{icon:g,name:"Ample Parking",description:"Secure parking spaces for residents and guests"},{icon:x,name:"Community Center",description:"Multipurpose space for events and gatherings"},{icon:u,name:"Children's Playground",description:"Safe and modern play areas for kids"},{icon:v,name:"Concierge Services",description:"Professional concierge and property management"}]}],m=[{title:"Premium Finishes",description:"High-quality materials and finishes throughout all properties",image:"/img_0380.jpg"},{title:"Modern Architecture",description:"Contemporary designs with clean lines and functional spaces",image:"/img_0419.jpg"},{title:"Smart Home Integration",description:"Advanced home automation systems for convenience and security",image:"/img_0400.jpg"}];return e.jsx("main",{className:"bg-black text-white min-h-screen",children:e.jsx("section",{className:"pt-32 pb-20",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-6",children:[e.jsxs(a.div,{initial:{opacity:0,y:30},animate:{opacity:1,y:0},transition:{duration:.8},className:"text-center mb-20",children:[e.jsx("div",{className:"h-0.5 w-20 bg-[#C9A24D] mb-8 mx-auto"}),e.jsx("h1",{className:"text-5xl md:text-6xl mb-6",children:"Amenities & Features"}),e.jsx("p",{className:"text-xl text-white/70 max-w-3xl mx-auto leading-relaxed",children:"Experience luxury living with world-class amenities designed for comfort, convenience, and elevated lifestyle"})]}),e.jsx("div",{className:"space-y-24 mb-32",children:d.map((i,s)=>{const p=i.icon;return e.jsxs(a.div,{initial:{opacity:0,y:40},animate:{opacity:1,y:0},transition:{duration:.8,delay:s*.1},children:[e.jsxs("div",{className:"flex items-center gap-4 mb-10",children:[e.jsx("div",{className:"w-14 h-14 bg-[#C9A24D]/10 flex items-center justify-center",children:e.jsx(p,{className:"w-7 h-7 text-[#C9A24D]"})}),e.jsx("h2",{className:"text-3xl md:text-4xl",children:i.title})]}),e.jsx("div",{className:"grid md:grid-cols-2 gap-6",children:i.amenities.map((n,r)=>{const h=n.icon;return e.jsx(a.div,{initial:{opacity:0,x:-20},animate:{opacity:1,x:0},transition:{duration:.6,delay:s*.1+r*.05},className:"bg-white/5 border border-white/10 p-6 hover:border-[#C9A24D]/50 transition-colors group",children:e.jsxs("div",{className:"flex items-start gap-4",children:[e.jsx("div",{className:"w-12 h-12 bg-[#C9A24D]/10 flex items-center justify-center flex-shrink-0 group-hover:bg-[#C9A24D]/20 transition-colors",children:e.jsx(h,{className:"w-6 h-6 text-[#C9A24D]"})}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-xl mb-2",children:n.name}),e.jsx("p",{className:"text-white/60 text-sm leading-relaxed",children:n.description})]})]})},r)})})]},s)})}),e.jsxs(a.div,{initial:{opacity:0,y:30},animate:{opacity:1,y:0},transition:{duration:.8,delay:.5},className:"mb-32",children:[e.jsx("h2",{className:"text-3xl md:text-4xl mb-4 text-center",children:"Property Features"}),e.jsx("p",{className:"text-white/60 text-center max-w-2xl mx-auto mb-16",children:"Every detail carefully considered for exceptional living"}),e.jsx("div",{className:"grid md:grid-cols-3 gap-8",children:m.map((i,s)=>e.jsxs(a.div,{initial:{opacity:0,y:30},animate:{opacity:1,y:0},transition:{duration:.6,delay:.6+s*.1},className:"group relative h-[400px] overflow-hidden",children:[e.jsx("img",{src:i.image,alt:i.title,className:"w-full h-full object-cover transition-transform duration-700 group-hover:scale-110",loading:"lazy"}),e.jsx("div",{className:"absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"}),e.jsxs("div",{className:"absolute bottom-0 left-0 right-0 p-6",children:[e.jsx("h3",{className:"text-2xl font-semibold mb-3",children:i.title}),e.jsx("p",{className:"text-white/80 leading-relaxed",children:i.description})]})]},s))})]}),e.jsxs(a.div,{initial:{opacity:0,y:30},animate:{opacity:1,y:0},transition:{duration:.8,delay:.8},className:"bg-white/5 border border-white/10 p-12",children:[e.jsx("h2",{className:"text-3xl md:text-4xl mb-6 text-center",children:"The Just Core Difference"}),e.jsx("p",{className:"text-white/70 leading-relaxed max-w-4xl mx-auto text-center mb-10",children:"At Just Core Realty and Interiors, we believe that luxury is not just about opulence—it's about creating environments that enhance your quality of life. Our properties combine premium amenities with thoughtful design, ensuring that every resident enjoys an exceptional living experience. From state-of-the-art fitness facilities to comprehensive security systems, every amenity is carefully selected and maintained to the highest standards."}),e.jsxs("div",{className:"grid md:grid-cols-3 gap-6 mt-10",children:[e.jsxs("div",{className:"text-center",children:[e.jsx("div",{className:"text-4xl font-bold text-[#C9A24D] mb-2",children:"100%"}),e.jsx("p",{className:"text-white/60",children:"Power Availability"})]}),e.jsxs("div",{className:"text-center",children:[e.jsx("div",{className:"text-4xl font-bold text-[#C9A24D] mb-2",children:"24/7"}),e.jsx("p",{className:"text-white/60",children:"Security & Support"})]}),e.jsxs("div",{className:"text-center",children:[e.jsx("div",{className:"text-4xl font-bold text-[#C9A24D] mb-2",children:"World-Class"}),e.jsx("p",{className:"text-white/60",children:"Facilities"})]})]})]}),e.jsxs(a.div,{initial:{opacity:0,y:30},animate:{opacity:1,y:0},transition:{duration:.8,delay:.9},className:"mt-32 bg-[#C9A24D] text-black p-12 text-center",children:[e.jsx("h2",{className:"text-3xl md:text-4xl mb-6",children:"Experience Luxury Living"}),e.jsx("p",{className:"text-lg mb-8 opacity-90 max-w-2xl mx-auto",children:"Schedule a tour to experience our world-class amenities and exceptional properties firsthand"}),e.jsx("a",{href:"/contact",className:"inline-block bg-black text-white px-10 py-4 text-lg font-semibold hover:bg-black/90 transition-colors",children:"Schedule a Tour"})]})]})})})}export{D as default};
